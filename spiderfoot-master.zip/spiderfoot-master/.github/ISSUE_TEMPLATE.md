Please provide a description of the issue and any relevant error messages.

If you can provide an application stack trace that is even better.

What version of Python are you using?

What version of SpiderFoot are you using (stable release or Git `master` branch)?

You may also wish to check if your issue has been posted previously:

* https://github.com/smicallef/spiderfoot/issues

